"""Package a completed, hash-verified reproduction for reviewers.

This creates a local ZIP, not a public release. It refuses failed/incomplete
runs, changed sources, stale artifacts, and changed logs. The archive includes
the exact inputs, generated paper/results, and provenance of the passing run.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile


HERE = Path(__file__).resolve().parent
PREFIX = "neurosymbolic-reproduction"
VERSION = "v1.2.1"
RELEASE_URL = "https://github.com/vmpreciado/NeuroSymbolic/releases/tag/" + VERSION
PUBLICATION_STATUS = "release artifact; publication and immutability are established by the GitHub release record"
MINIMUM_STAGES = 15
REQUIRED_SOURCES = {
    "run_all.py", "package_reproduction.py", "rounding.py", "bounds.py",
    "cegis_c.py", "experiments.py", "residual.py", "bench_pendulum.py",
    "bench_neural.py", "smoke_p1.py", "fill_tex.py", "README.md", "CITATION.cff",
    "requirements.txt", "requirements-lock.txt",
    "paper/nsp_contraction_paper_ieee.tex",
    "revision_experiments.py", "revision_extensions.py", "revision_report.py",
    "RESPONSE_TO_CLAUDE.md", "release/build_arxiv.py",
    "application_comparison.py", "application_protocol.json",
    "application_baseline.py", "application_verifier.py", "application_report.py",
    "application_constant_baseline.py", "tests/test_application_constant_baseline.py",
    "polynomial_constant_baseline.py", "tests/test_polynomial_constant_baseline.py",
    "comparison_sources/fitzsimmons_liu_2024.json",
    "comparison_sources/preliminary_application_summary.json",
    "release/build_application_packet.py", "release/verify_application_packet.py",
}
REQUIRED_ARTIFACTS = {
    "results/traces.json", "results/gridcost.json", "results/residual.json",
    "results/pendulum.json", "results/neural.json", "results/smoke_p1.json",
    "results/rounding_checks.json", "paper/numbers.tex",
    "paper/nsp_contraction_paper_ieee.pdf",
    "results/revision_experiments.json", "results/revision_extensions.json",
    "results/revision_report.json", "results/timing_revision.json",
    "results/arxiv_bundle.json", "paper/revision_numbers.tex", "paper/revision_tables.tex",
    "results/application_comparison.json", "paper/application_numbers.tex",
    "results/application_constant_baseline.json",
    "results/polynomial_constant_baseline.json", "paper/polynomial_constant_numbers.tex",
    "paper/application_tables.tex", "paper/fig_application.pdf",
    *("paper/fig_" + name + ".pdf" for name in
      ("ablation", "scale_chase", "extension3d", "surrogate")),
    *("paper/fig_" + name + ".pdf" for name in
      ("traces", "heatmaps", "gridcost", "residual", "pendulum", "neural")),
}


def digest(content):
    return hashlib.sha256(content).hexdigest()


def checked_bytes(root, relative, expected=None):
    path = PurePosixPath(relative)
    if path.is_absolute() or ".." in path.parts or "\\" in relative:
        raise ValueError(f"unsafe snapshot path: {relative}")
    resolved = root / relative
    if not resolved.resolve().is_relative_to(root.resolve()) or resolved.is_symlink():
        raise ValueError(f"snapshot path escapes the project or is a symlink: {relative}")
    content = resolved.read_bytes()
    if expected is not None and digest(content) != expected:
        raise ValueError(f"content changed since the passing run: {relative}")
    return content


def snapshot_files(root):
    root = Path(root)
    manifest_path = "results/run_manifest.json"
    manifest_bytes = checked_bytes(root, manifest_path)
    manifest = json.loads(manifest_bytes)
    stages = manifest.get("stages", [])
    expected = manifest.get("expected_stage_count", 0)
    if (manifest.get("status") != "pass" or not isinstance(expected, int) or expected < MINIMUM_STAGES
            or len(stages) != expected
            or any(stage.get("status") != "pass" for stage in stages)):
        raise ValueError("a complete passing reproduction with every declared stage is required")
    sources = manifest.get("sources_at_finish", {})
    artifacts = manifest.get("artifact_sha256", {})
    if sources != manifest.get("sources_at_start"):
        raise ValueError("sources changed during the pipeline; rerun before packaging")
    if not REQUIRED_SOURCES.issubset(sources) or not REQUIRED_ARTIFACTS.issubset(artifacts):
        raise ValueError("manifest omits required reproduction sources or artifacts")
    recorded = dict(sources)
    recorded.update(artifacts)
    recorded[manifest["run_log"]] = manifest["run_log_sha256"]
    for stage in stages:
        recorded[stage["log"]] = stage["log_sha256"]
    files = {name: checked_bytes(root, name, expected)
             for name, expected in sorted(recorded.items())}
    files[manifest_path] = manifest_bytes
    snapshot = {
        "schema_version": 1,
        "description": "Complete verified scientific reproduction for " + VERSION,
        "release_tag": VERSION,
        "release_url": RELEASE_URL,
        "publication_status": PUBLICATION_STATUS,
        "pipeline_finished_at": manifest["finished_at"],
        "run_manifest_sha256": digest(manifest_bytes),
        "files": {name: digest(content) for name, content in sorted(files.items())},
    }
    files["SNAPSHOT.json"] = (json.dumps(snapshot, indent=2, sort_keys=True) + "\n").encode()
    return files


def package(root=HERE, destination=None):
    root = Path(root)
    destination = (Path(destination) if destination is not None
                   else root / "dist" / (PREFIX + ".zip"))
    files = snapshot_files(root)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(".zip.tmp")
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for name, content in sorted(files.items()):
            info = zipfile.ZipInfo(PREFIX + "/" + name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, content, compresslevel=9)
    temporary.replace(destination)
    checksum = digest(destination.read_bytes())
    destination.with_suffix(".zip.sha256").write_text(checksum + "  " + destination.name + "\n")
    return destination, checksum, len(files)


def verify_archive(path):
    """Verify a complete snapshot without extracting or executing its code."""
    with zipfile.ZipFile(path) as archive:
        members = archive.infolist()
        names = [member.filename for member in members]
        if len(names) != len(set(names)):
            raise ValueError("duplicate reproduction member")
        roots = set()
        for member in members:
            name = PurePosixPath(member.filename)
            if (name.is_absolute() or ".." in name.parts or "\\" in member.filename
                    or member.is_dir() or stat.S_ISLNK(member.external_attr >> 16)
                    or len(name.parts) < 2):
                raise ValueError("unsafe reproduction member")
            roots.add(name.parts[0])
        if len(roots) != 1:
            raise ValueError("reproduction must have one root")
        prefix = roots.pop() + "/"
        snapshot = json.loads(archive.read(prefix + "SNAPSHOT.json"))
        hashes = snapshot["files"]
        if set(names) != {prefix + name for name in hashes} | {prefix + "SNAPSHOT.json"}:
            raise ValueError("reproduction inventory differs from snapshot")
        files = {name: archive.read(prefix + name) for name in hashes}
    for name, expected in hashes.items():
        if digest(files[name]) != expected:
            raise ValueError("reproduction hash mismatch: " + name)
    run_bytes = files["results/run_manifest.json"]
    if digest(run_bytes) != snapshot["run_manifest_sha256"]:
        raise ValueError("reproduction run manifest hash mismatch")
    run = json.loads(run_bytes)
    stages = run.get("stages", [])
    expected = run.get("expected_stage_count", 0)
    if (run.get("status") != "pass" or not isinstance(expected, int) or expected < MINIMUM_STAGES
            or len(stages) != expected or any(s.get("status") != "pass" for s in stages)
            or run.get("sources_at_start") != run.get("sources_at_finish")):
        raise ValueError("reproduction is not a complete stable passing run")
    if (snapshot.get("release_tag") != VERSION or snapshot.get("release_url") != RELEASE_URL
            or snapshot.get("publication_status") != PUBLICATION_STATUS):
        raise ValueError("reproduction release metadata mismatch")
    sources, artifacts = run["sources_at_finish"], run["artifact_sha256"]
    if not REQUIRED_SOURCES.issubset(sources) or not REQUIRED_ARTIFACTS.issubset(artifacts):
        raise ValueError("reproduction omits required scientific sources or artifacts")
    recorded = dict(sources)
    recorded.update(artifacts)
    recorded[run["run_log"]] = run["run_log_sha256"]
    for stage in stages:
        recorded[stage["log"]] = stage["log_sha256"]
    recorded["results/run_manifest.json"] = digest(run_bytes)
    if set(recorded) != set(files):
        raise ValueError("reproduction payload differs from run provenance")
    for name, expected in recorded.items():
        if digest(files[name]) != expected:
            raise ValueError("run provenance mismatch: " + name)
    return {"status": "pass", "payload_files": len(files), "stages": len(stages),
            "run_manifest_sha256": digest(run_bytes)}, files


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--verify", type=Path, help="verify an existing archive without executing its code")
    args = parser.parse_args()
    if args.verify:
        print(json.dumps(verify_archive(args.verify)[0], indent=2))
        return
    path, checksum, count = package(destination=args.output)
    print(f"Packaged {count} files: {path}\nSHA256 {checksum}")


if __name__ == "__main__":
    main()
